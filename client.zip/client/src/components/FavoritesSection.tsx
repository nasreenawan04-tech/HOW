import { Link } from 'wouter';
import { useFavorites } from '@/hooks/use-favorites';
import ToolCard from '@/components/ToolCard';

const FavoritesSection = () => {
  // Always return null to hide this section
  return null;
};

export default FavoritesSection;